STEPS & HOW TO BUILD CODE:

VERSION USED:

Python 3.9

IMPLEMENTED USING:

IDLE 3.9.0

SYSTEM USED:

Mac OS 10.11.6

INSTALLATION AND THINGS TO DO:

Install IDLE 3.9.0/ any python tool upload document.
* The button color is different in Mac Os. So the color might differ.
The gif pictures should be added in order for the robots to display.


TO PLAY GAME:

Press the Start button to start the Game.
Any team can start since it’s random. 
Press NextTurn Button for each turn to battle with the opponent.
To End game, press QUIT button.
To reset the game, press the RESET button.

WHAT IS DONE:

For Interface, I have used TKINTER and the grid is created using the Buttons.
The SPINBOX is used to choose the number of robots to fight the battle. By default, the value is set as 8 robots for the purpose of standard play.
THE CONSOLE DISPLAYS EVERY MOVES ACTIVITY STATUS OF THE ROBOTS of each team.
The Player-1 is indicated in the RED robot.gif and the Player-2 is indicated in GREEN robot.gif. The picture is added along with the file.
The defeat is declared with a  MESSAGE according to the health and the weapons availability.
If you need to restart and reset the robots you have no choice but to restart the code, in order to picturize the buttons with correct team members.
The weapon is picked with the check of health of the current robot. The robot that gets deactivated gets activated when it takes moves on the weapon dropped place. So, that activated robot moves for its turn.
The default deactivated robot which is already placed in Arena gets activated and will take it’s turn when any team drops weapon on the place.
Finally, when all the robots that gets deactivated without any health then, the battle is won by the opponent.
The MESSAGE is displayed for the battle defeat team.
If you need to end game press Quit Button.







