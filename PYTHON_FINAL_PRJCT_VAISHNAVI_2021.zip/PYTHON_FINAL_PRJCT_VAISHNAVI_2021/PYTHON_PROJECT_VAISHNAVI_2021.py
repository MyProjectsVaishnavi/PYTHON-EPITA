from tkinter import *
from tkinter import messagebox
from tkinter import PhotoImage
import tkinter as tk
import random
import sys

root = Tk()
root.title("ROBOTS")
root.geometry("800x600")
l=Label(root,text="Player 1- Red",bg="white",fg="red",relief=RAISED).grid(row=4,column=16)
l1=Label(root,text="Player 2- Green",bg="white",fg="red",relief=RAISED).grid(row=7,column=16)
v=StringVar(root)
v.set("8")
spin = Spinbox(root, from_=0, to=8, width=8, textvariable=v)
spin.grid(row=5,column=16)
spin1 = Spinbox(root, from_=0, to=8, width=8, textvariable=v)
spin1.grid(row=8,column=16)
row=[3,8]
col=[7,8,9,10,11,12]
body=["simple","hard","light","battle"]
hp={'simple':2,'hard':5,'light':3,'battle':2}
movement={'simple':1,'hard':1,'light':1,'battle':1}
weap={'simple':0,'hard':0,'light':1,'battle':1}
imageTest = PhotoImage(file="red robot.gif")
imageTest1 = PhotoImage(file="robots.gif")
def helloCallBack():
    print("Game Started")
    
class Robot:
    def __init__(self, HP, body, weapon, movement, direction, position):
        self.HP=HP
        self.body=body
        self.weapon=weapon
        self.movement=movement
        self.direction=direction
        self.position=position
class Body:
    def __init__(self, HP, movement, weapon):
        self.HP = HP
        self.movement = movement
        self.weapon = weapon

class Simple(Body):
    def __init__(self):
        super().__init__(2, 1, 0)

class Hard(Body):
    def __init__(self):
        super().__init__(5, 1, 0)

class Light(Body):
    def __init__(self):
        super().__init__(3, 1, 0)

class Battle(Body):
    def __init__(self):
        super().__init__(2, 1, 1)


class Weapon:
    def __init__(self, Range, Dmg):
        self.Range = Range
        self.Dmg = Dmg

class Basic(Weapon):
    def __init__(self):
        super().__init__(0, 1)

class Laser(Weapon):
    def __init__(self):
        super().__init__(0, 1)

class Sword(Weapon):
    def __init__(self):
        super().__init__(0, 2)

class Explosion(Weapon):
    def __init__(self):
        super().__init__(0, 1)

class Dual_Laser(Weapon):
    def __init__(self):
        super().__init__(0, 1)

class Play_Game(Body):
    global count
    #Check for the robot movement
    def movement_check(self,bodie):
        count=0
        super().__init__(0, 0, 0)
        if bodie=="simple":
            health=hp.get('simple')
            move=movement.get('simple')
            weapons=0
            if health>=1:
                print("Simple Body!!")
            return move,weapons,health
        elif bodie=="light":
            health=hp.get('light')
            move=movement.get('light')
            weapons=0
            if count==1:
                move=move-1
                count=2
            if health>=1:
                count=1
                print("Light Body!!")
            return move,weapons,health
        elif bodie=="hard":
            health=hp.get('hard')
            move=movement.get('hard')
            weapons=0
            if count==1:
                move=move-1
                count=2
            if health>=1:
                count=1
                print("Hard Body!!")
            return move,weapons,health
        else:
            health=hp.get('battle')
            move=movement.get('battle')
            weapons=weap.get('battle')
            if count==1:
                move=move-1
                count=2
            if health>=1:
                count=1
                print("Battle Body!!")
            return move,weapons,health
play=Play_Game(0,0,0)
count=1
r,c,cols1,rows1=0,0,0,0
next_count=0
next_count1=0
row_count=0
flag=0
flag1=0

def nextTurn(b1):
        global count
        global next_count,next_count1
        global row_count
        global r,c,cols1,rows1
        global flag,flag1
        global cnt,cnt1
        global bodie
        r1=random.choice(row)
        r2=random.choice(col)
        r3=random.choice(body)
        
        #Check for the movement in the cells for the health.
        def simpleBody(bodie,r1,r2,move_check,health,weapons):  
            if flag<=6 and flag1<=12:
                rows=r1
                cols=r2
                if move_check>=1 and weapons>=1:
                    weapons=weapons-1
                    health=health-1
                return bodie,r1,r2,health,weapons
        def battleBody(bodie,r1,r2,move_check,health,weapons):
            if flag<=6 and flag1<=12:
                rows1=r1
                cols1=r2
                if move_check>=1 and weapons>=1:
                    weapons=weapons-1
                    health=health-1
                return bodie,r1,r2,health,weapons
        def lightBody(bodie,r1,r2,move_check,health,weapons):
            if flag<=6 and flag1<=12:
                rows1=r1
                cols1=r2
                if move_check>=1 and weapons>=1:
                    weapons=weapons-1
                    health=health-1
                return bodie,r1,r2,health,weapons
        def hardBody(bodie,r1,r2,move_check,health,weapons):
            if flag<=6 and flag1<=12 and bodie=="hard":
                rows1=r1
                cols1=r2
                if move_check>=1 and weapons>=1:
                    weapons=weapons-1
                    health=health-1
                return bodie,r1,r2,health,weapons

        def attack_check(bodie,rows,cols,health,w1):
            
            print("Team 1 Attack Started")
            if bodie=="simple":
                    health=health-1
                    w1=w1-1
                    b= Button(root, text=" ",height=2,width=5,highlightbackground="orange",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    b.grid(row=rows,column=cols)
                    print("1- Robot Attacked")
                    return health
            if bodie=="light":
                    health=health-1
                    w1=w1-1
                    b= Button(root, text=" ",height=2,width=5,highlightbackground="orange",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    b.grid(row=rows,column=cols)
                    print("1- Robot Attacked")
                    return health
            if bodie=="hard":
                    health=health-1
                    w1=w1-1
                    b= Button(root, text=" ",height=2,width=5,highlightbackground="orange",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    b.grid(row=rows,column=cols)
                    print("1- Robot Attacked")
                    return health
            if bodie=="battle":
                    health=health-1
                    w1=w1-1
                    b= Button(root, text=" ",height=2,width=5,highlightbackground="orange",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    b.grid(row=rows,column=cols)
                    print("1- Robot Attacked")
                    return health
            return health
            
        def attack_check2(bodie,rows,cols,health,w1):
            print("Team 2 Attack Started")
            if bodie=="simple":
                    health=health-1
                    w1=w1-1
                    c2=1
                    b= Button(root, text=" ",height=2,width=5,highlightbackground="orange",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    b.grid(row=rows,column=cols)
                    print("1- Robot Attacked")
                    return health
            if bodie=="light":
                    health=health-1
                    w1=w1-1
                    c2=1
                    b= Button(root, text=" ",height=2,width=5,highlightbackground="orange",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    b.grid(row=rows,column=cols)
                    print("1- Robot Attacked")
                    return health
            if bodie=="hard":
                    health=health-1
                    w1=w1-1
                    c2=1
                    b= Button(root, text=" ",height=2,width=5,highlightbackground="orange",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    b.grid(row=rows,column=cols)
                    print("1- Robot Attacked")
                    return health
            if bodie=="battle":
                    health=health-1
                    w1=w1-1
                    c2=1
                    b= Button(root, text=" ",height=2,width=5,highlightbackground="orange",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    b.grid(row=rows,column=cols)
                    print("1- Robot Attacked")
                    return health
            return health       

        if(count==1):
            b= Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
            b.grid(row=3,column=r2)
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
            bn.grid(row=8,column=r2)
            count=count-1
        if count<1:
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
            bn.grid(row=r1,column=r2)
        
        if r1==3 and r2==7:
            flag=1
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest,compound="center")
            bn.grid(row=r1,column=r2)
            r1=4
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                
                move_check,weapons,health=play.movement_check(bodie)
                bdy=r3
                r1,prev=5,5
                c1=0
                move_check=int(move_check or 0)
                while (move_check>=1 and r1<8):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=prev,column=r2)
                    
                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    
                    prev=r1
                    r1=r1+1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                    
                if health<=1:
                    
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count=next_count+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
            
        if r1==3 and r2==8:
            flag=2
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=4
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)
                move_check=int(move_check or 0)
                r1,prev=5,5
                c1=0

                while (move_check>=1 and r1<8):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=r1,column=r2)
                   
                    
                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                    
                    prev=r1
                    r1=r1+1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                    
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count=next_count+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if r1==3 and r2==9:
            flag=3
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=4
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)
                move_check=int(move_check or 0)
                r1,prev=5,5
                c1=0
                while (move_check>=1 and r1<8):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=r1,column=r2)
                   

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                    
                    prev=r1
                    r1=r1+1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                    
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count=next_count+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if r1==3 and r2==10:
            flag=4
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=4
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)
                move_check=int(move_check or 0)
                r1,prev=5,5
                c1=0
                while (move_check>=1 and r1<8):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=r1,column=r2)

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                        health=attack_check(bodie,rows,cols,health,w1)  
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                    
                    prev=r1
                    r1=r1+1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                    
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count=next_count+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if r1==3 and r2==11:
            flag=5
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=4
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)
                move_check=int(move_check or 0)
                r1,prev=5,5
                c1=0
                while (move_check>=1 and r1<8):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=prev,column=r2)
                   

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                    
                    prev=r1
                    r1=r1+1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                    
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count=next_count+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if r1==3 and r2==12:
            flag=6
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=4
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)
                move_check=int(move_check or 0)
                r1,prev=5,5
                c1=0

                while (move_check>=1 and r1<8):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=prev,column=r2)

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check(bodie,rows,cols,health,w1)
                    
                    prev=r1
                    r1=r1+1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count=next_count+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if next_count==12:
            messagebox.showinfo("Congratulations", "Player-2 Won!!")
            print("Player-1 has More Dead Robots")
            sys.exit("Game Ended")
        if r1==8 and r2==7:
            flag1=7
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=7
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)
                move_check=int(move_check or 0)
                r1,prev=6,6
                while (move_check>=1 and r1>=3):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=prev,column=r2)

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                    prev=r1
                    r1=r1-1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count1=next_count1+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if r1==8 and r2==8:
            flag1=8
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=7
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)
                move_check=int(move_check or 0)
                r1,prev=6,6
                while (move_check>=1 and r1>=3):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=prev,column=r2)

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                    prev=r1
                    r1=r1-1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count1=next_count1+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if r1==8 and r2==9:
            flag1=9
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=7
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)
                move_check=int(move_check or 0)
                r1,prev=6,6
                while (move_check>=1 and r1>=3):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=prev,column=r2)

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                    prev=r1
                    r1=r1-1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                    
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count1=next_count1+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if r1==8 and r2==10:
            flag1=10
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=7
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)
                move_check=int(move_check or 0)
                r1,prev=6,6
                while (move_check>=1 and r1>=3):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=prev,column=r2)

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                    prev=r1
                    r1=r1-1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                    
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count1=next_count1+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if r1==8 and r2==11:
            flag1=11
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=7
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)

                move_check=int(move_check or 0)
                r1,prev=6,6
                while (move_check>=1 and r1>=3):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=prev,column=r2)

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                    prev=r1
                    r1=r1-1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                    
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    next_count1=next_count1+1
                    print("Deactivated")
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if r1==8 and r2==12:
            flag1=12
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
            bn.grid(row=r1,column=r2)
            r1=7
            bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
            bn.grid(row=r1,column=r2)
            bodie=r3
            if r3=="simple" or r3=="light" or r3=="hard" or r3=="battle":
                move_check,weapons,health=play.movement_check(bodie)

                move_check=int(move_check or 0)
                r1,prev=6,6
                while (move_check>=1 and r1>=3):
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=prev,column=r2)

                    if bodie=="simple":
                        bodie,rows,cols,health,w1=simpleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="light":
                        bodie,rows,cols,health,w1=lightBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    elif bodie=="hard":
                        bodie,rows,cols,health,w1=hardBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                          
                    else:
                        bodie,rows,cols,health,w1=battleBody(bodie,r1,r2,move_check,health,weapons)
                        health=attack_check2(bodie,rows,cols,health,w1)
                    prev=r1
                    r1=r1-1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="white",command=lambda: nextTurn(b1))
                    bn.grid(row=prev,column=r2)
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="green",command=lambda: nextTurn(b1),image=imageTest1,compound="center")
                    bn.grid(row=r1,column=r2)
                    move_check=move_check-1
                    
                if health<=1:
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
                    print("Deactivated")
                    next_count1=next_count1+1
                    bn=Button(root, text=" ",height=2,width=5,highlightbackground="violet",command=lambda: nextTurn(b1))
                    bn.grid(row=r1,column=r2)
        if next_count1==12:
            messagebox.showinfo("Congratulations!!!", "Player-1 Won!!")
            print("Player-2 has More Dead Robots")
            sys.exit("Game Ended")  

def StopCallBack():
    print("Ended")
    messagebox.showinfo("Quit", "Game Ended!")
    sys.exit("Game Ended")
ba= Button(root, text="Reset", command=lambda: restartGame(ba),highlightbackground='#3E4149')
ba.grid(row=0, column=7)
b1 = Button(root, text ="Start",command=lambda: helloCallBack(),highlightbackground='silver')
b1.grid(row=0,column=4)
b= Button(root, text="Next Turn", command=lambda: nextTurn(b1),highlightbackground='#3E4149')
b.grid(row=0, column=5)
b2 = Button(root, text="Quit", command= StopCallBack,highlightbackground='silver')
b2.grid(row=0, column=6)
def restartGame(ba):
    print("Tried to Restart")
    messagebox.showinfo("Restart", "Re-Run The Code!")
    
if(True):
        b3= Button(root, text=" ",height=2,width=5,highlightbackground='#3E4149', image=imageTest, compound="center")
        b4= Button(root, text=" ",height=2,width=5,highlightbackground='#3E4149',image=imageTest, compound="center")
        b5= Button(root, text=" ",height=2,width=5,highlightbackground='#3E4149',image=imageTest, compound="center")
        b6= Button(root, text=" ",height=2,width=5,highlightbackground='#3E4149',image=imageTest, compound="center")
        b7= Button(root, text=" ",height=2,width=5,highlightbackground='#3E4149',image=imageTest, compound="center")
        b8= Button(root, text=" ",height=2,width=5,highlightbackground='#3E4149',image=imageTest, compound="center")
        
        b9= Button(root, text=" ",height=2,width=5)
        b10= Button(root, text=" ",height=2,width=5)
        b11= Button(root, text=" ",height=2,width=5,highlightbackground="blue")
        b12= Button(root, text=" ",height=2,width=5)
        b13= Button(root, text=" ",height=2,width=5,highlightbackground="blue")
        b14= Button(root, text=" ",height=2,width=5)
        
        b15= Button(root, text=" ",height=2,width=5)
        b16= Button(root, text=" ",height=2,width=5,highlightbackground="blue")
        b17= Button(root, text=" ",height=2,width=5,)
        b18= Button(root, text=" ",height=2,width=5,highlightbackground="blue")
        b19= Button(root, text=" ",height=2,width=5)
        b20= Button(root, text=" ",height=2,width=5)
        
        b21= Button(root, text=" ",height=2,width=5,highlightbackground="blue")
        b22= Button(root, text=" ",height=2,width=5)
        b23= Button(root, text=" ",height=2,width=5,highlightbackground="blue")
        b24= Button(root, text=" ",height=2,width=5)
        b25= Button(root, text=" ",height=2,width=5)
        b26= Button(root, text=" ",height=2,width=5,highlightbackground="blue")

        b27= Button(root, text=" ",height=2,width=5)
        b28= Button(root, text=" ",height=2,width=5)
        b29= Button(root, text=" ",height=2,width=5)
        b30= Button(root, text=" ",height=2,width=5,highlightbackground="blue")
        b31= Button(root, text=" ",height=2,width=5)
        b32= Button(root, text=" ",height=2,width=5)

        b33= Button(root, text=" ",height=2,width=5,highlightbackground="red",image=imageTest1, compound="center")
        b34= Button(root, text=" ",height=2,width=5,highlightbackground="red",image=imageTest1, compound="center")
        b35= Button(root, text=" ",height=2,width=5,highlightbackground="red",image=imageTest1, compound="center")
        b36= Button(root, text=" ",height=2,width=5,highlightbackground="red",image=imageTest1, compound="center")
        b37= Button(root, text=" ",height=2,width=5,highlightbackground="red",image=imageTest1, compound="center")
        b38= Button(root, text=" ",height=2,width=5,highlightbackground="red",image=imageTest1, compound="center")
        
        b3.grid(row=3, column=7)
        b4.grid(row=3, column=8)
        b5.grid(row=3, column=9)
        b6.grid(row=3, column=10)
        b7.grid(row=3, column=11)
        b8.grid(row=3, column=12)
        
        b9.grid(row=4, column=7)
        b10.grid(row=4, column=8)
        b11.grid(row=4, column=9)
        b12.grid(row=4, column=10)
        b13.grid(row=4, column=11)
        b14.grid(row=4, column=12)
        
        b15.grid(row=5, column=7)
        b16.grid(row=5, column=8)
        b17.grid(row=5, column=9)
        b18.grid(row=5, column=10)
        b19.grid(row=5, column=11)
        b20.grid(row=5, column=12)
        
        b21.grid(row=6, column=7)
        b22.grid(row=6, column=8)
        b23.grid(row=6, column=9)
        b24.grid(row=6, column=10)
        b25.grid(row=6, column=11)
        b26.grid(row=6, column=12)
        
        b27.grid(row=7, column=7)
        b28.grid(row=7, column=8)
        b29.grid(row=7, column=9)
        b30.grid(row=7, column=10)
        b31.grid(row=7, column=11)
        b32.grid(row=7, column=12)
        
        b33.grid(row=8, column=7)
        b34.grid(row=8, column=8)
        b35.grid(row=8, column=9)
        b36.grid(row=8, column=10)
        b37.grid(row=8, column=11)
        b38.grid(row=8, column=12)

root.mainloop()

